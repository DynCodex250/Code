#' Lizenztreiber pro Privilege zusammenfassen
#'
#' Verdichtet die Lizenztreiber-Tabelle auf eine Zeile pro Duty und
#' Privilege: welche Lizenz das Privilege mindestens erfordert, welche Entry
#' Points das auslösen und ob das Privilege die Lizenz seiner Duty bestimmt.
#'
#' @details
#'
#' Die Funktion ist das Gegenstück zu
#' \code{\link{summarize_duty_license_drivers}} eine Ebene tiefer. Sie
#' beantwortet die Frage, warum eine Duty eine bestimmte Lizenz braucht:
#' Die Zeilen mit \code{DRIVES_DUTY = TRUE} sind die Privileges, die die
#' Lizenz der Duty auslösen.
#'
#' Ein Privilege, das in mehreren Duties vorkommt, erscheint einmal pro Duty.
#'
#' @param drivers
#' Ergebnis von \code{\link{build_role_license_drivers}} bzw.
#' \code{\link{get_role_license_drivers}}.
#'
#' @return
#'
#' Tibble mit einer Zeile pro Duty und Privilege:
#'
#' \describe{
#'   \item{\code{DUTYIDENTIFIER}, \code{DUTYNAME}}{Duty.}
#'   \item{\code{PRIVILEGEIDENTIFIER}, \code{PRIVILEGENAME}}{Privilege.}
#'   \item{\code{PRIVILEGE_SKU}, \code{PRIVILEGE_PRIORITY}}{Teuerste
#'     Mindestlizenz des Privilege (\code{NA}, wenn keine Lizenzinformation
#'     vorliegt).}
#'   \item{\code{IS_BASE_LICENSE}}{\code{TRUE}, wenn \code{PRIVILEGE_SKU}
#'     eine Base-Lizenz ist.}
#'   \item{\code{DRIVES_DUTY}}{\code{TRUE}, wenn das Privilege die Lizenz
#'     seiner Duty bestimmt.}
#'   \item{\code{ENTRYPOINT_COUNT}}{Entry Points des Privilege.}
#'   \item{\code{DRIVER_ENTRYPOINTS}}{Entry Points, die \code{PRIVILEGE_SKU}
#'     auslösen.}
#'   \item{\code{LICENSE_STATUS}}{Lizenzstatus der Entry Points, siehe
#'     \code{\link{build_role_license_drivers}}.}
#' }
#'
#' Sortiert nach \code{PRIVILEGE_PRIORITY} (teuerste zuerst).
#'
#' @examples
#' \dontrun{
#'
#' cnn     <- get_connection("PRJ", "db_credentials.xlsx")
#' drivers <- get_role_license_drivers(cnn, "_WIBU_VERKAUF_INNENDIENST_MITARBEITER")
#'
#' privileges <- summarize_privilege_license_drivers(drivers)
#'
#' # Welche Privileges lösen die Lizenz einer Duty aus?
#' privileges |>
#'   dplyr::filter(DUTYIDENTIFIER == "CustCustomersMaintain", DRIVES_DUTY)
#'
#' # Privileges ohne Lizenzinformation
#' privileges |> dplyr::filter(is.na(PRIVILEGE_SKU))
#'
#' }
#'
#' @seealso
#' \code{\link{summarize_duty_license_drivers}}
#' \code{\link{summarize_role_license_skus}}
#' \code{\link{get_privilege_license_map}}
#'
#' @export
summarize_privilege_license_drivers <- function(drivers) {

  .check_required_columns(drivers, .driver_columns(), "drivers")

  drivers |>
    dplyr::group_by(
      DUTYIDENTIFIER, DUTYNAME, PRIVILEGEIDENTIFIER, PRIVILEGENAME
    ) |>
    dplyr::mutate(
      DRIVES_PRIVILEGE = !is.na(MIN_SKU) & MIN_SKU == PRIVILEGE_SKU
    ) |>
    dplyr::summarise(
      PRIVILEGE_SKU      = dplyr::first(PRIVILEGE_SKU),
      PRIVILEGE_PRIORITY = .max_or_na(MIN_PRIORITY),
      IS_BASE_LICENSE    = any(IS_BASE_LICENSE & DRIVES_PRIVILEGE),
      DRIVES_DUTY        = any(DRIVES_DUTY),
      ENTRYPOINT_COUNT   = dplyr::n_distinct(ENTRYPOINT[!is.na(ENTRYPOINT)]),
      DRIVER_ENTRYPOINTS = .collapse_sorted(
        ENTRYPOINT[DRIVES_PRIVILEGE], .LIST_SEPARATOR
      ),
      LICENSE_STATUS     = .collapse_sorted(LICENSE_STATUS, .LIST_SEPARATOR),
      .groups            = "drop"
    ) |>
    dplyr::arrange(
      dplyr::desc(PRIVILEGE_PRIORITY),   # teuerste Lizenz zuerst
      DUTYIDENTIFIER,
      PRIVILEGEIDENTIFIER
    )
}
